package com.familypersatuan.creator

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.*
import android.view.*
import android.content.Context
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.util.Locale

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(CreatorApp(this))
    }
}

class CreatorApp(private val ctx: Context): View(ctx) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private val purple=Color.rgb(109,40,217); private val dark=Color.rgb(24,32,51)
    private val muted=Color.rgb(105,115,134); private val bg=Color.rgb(247,249,252)
    private val gold=Color.rgb(245,197,66)
    private var mode="login"; private var tab=0; private var adminTab=0
    private var checkedMember: Member? = null
    private var pendingInvitationCount = 0
    private var currentRole = "member"

    private fun firebaseReady(): Boolean {
        return try {
            if (FirebaseApp.getApps(ctx).isEmpty()) {
                val apiKey=ctx.getString(com.familypersatuan.creator.R.string.firebase_api_key)
                val appId=ctx.getString(com.familypersatuan.creator.R.string.firebase_app_id)
                val projectId=ctx.getString(com.familypersatuan.creator.R.string.firebase_project_id)
                if (apiKey.startsWith("GANTI_") || appId.startsWith("GANTI_") || projectId.startsWith("GANTI_")) return false
                FirebaseApp.initializeApp(ctx, FirebaseOptions.Builder()
                    .setApiKey(apiKey).setApplicationId(appId).setProjectId(projectId)
                    .setStorageBucket(ctx.getString(com.familypersatuan.creator.R.string.firebase_storage_bucket))
                    .build())
            }
            FirebaseApp.getApps(ctx).isNotEmpty()
        } catch (_: Exception) { false }
    }

    init { isClickable=true }

    private fun txt(c:Canvas,s:String,x:Float,y:Float,z:Float,col:Int=dark,b:Boolean=false){
        p.color=col;p.textSize=z;p.typeface=Typeface.create("sans",if(b)Typeface.BOLD else Typeface.NORMAL);c.drawText(s,x,y,p)
    }
    private fun box(c:Canvas,l:Float,t:Float,r:Float,b:Float,col:Int,rad:Float=16f){
        p.color=col;c.drawRoundRect(l,t,r,b,rad,rad,p)
    }
    private fun btn(c:Canvas,s:String,y:Float){
        box(c,22f,y,408f,y+50f,purple,14f);txt(c,s,142f,y+32f,13f,Color.WHITE,true)
    }

    override fun onDraw(c:Canvas){
        c.drawColor(bg)
        when(mode){
            "login"->login(c)
            "register"->register(c)
            "admin"->admin(c)
            else->{head(c);when(tab){0->home(c);1->cards(c);2->bonus(c);3->rank(c);4->profile(c)};nav(c)}
        }
    }

    private fun login(c:Canvas){
        val g=LinearGradient(0f,0f,0f,height.toFloat(),Color.rgb(50,18,95),purple,Shader.TileMode.CLAMP)
        p.shader=g;c.drawRect(0f,0f,width.toFloat(),height.toFloat(),p);p.shader=null
        txt(c,"♛",180f,115f,50f,gold,true);txt(c,"FAMILY",137f,165f,28f,Color.WHITE,true)
        txt(c,"PERSATUAN PEJUANG",92f,192f,15f,gold,true);txt(c,"CREATOR",160f,216f,15f,Color.WHITE,true)
        box(c,22f,255f,408f,520f,Color.WHITE,22f)
        txt(c,"Masuk ke Akun",48f,298f,20f,dark,true)
        txt(c,"Username",48f,330f,11f,muted);box(c,48f,340f,382f,385f,0xFFF1F3F7.toInt(),11f);txt(c,"Contoh: wahyudipratama316",62f,367f,13f,muted)
        txt(c,"Password",48f,412f,11f,muted);box(c,48f,422f,382f,467f,0xFFF1F3F7.toInt(),11f);txt(c,"Minimal 6 karakter",62f,449f,13f,muted)
        btn(c,"MASUK",478f);txt(c,"Belum punya akun? DAFTAR",122f,565f,12f,purple,true)
    }

    private fun register(c:Canvas){
        txt(c,"←  Daftar Akun",20f,50f,20f,dark,true)
        txt(c,"Buat akun creator baru",22f,84f,13f,muted)
        val f=arrayOf("Nama Lengkap","Email","Password / PIN","Kode Referral (opsional)")
        for(i in f.indices){val y=115+i*80;txt(c,f[i],22f,y,11f,muted);box(c,22f,y+10,408f,y+55,Color.WHITE,11f);txt(c,"Tekan DAFTAR untuk mengisi",37f,y+39,13f,muted)}
        btn(c,"DAFTAR",455f);txt(c,"Sudah punya akun? MASUK",132f,548f,12f,purple,true)
    }

    private fun head(c:Canvas){
        val g=LinearGradient(0f,0f,width.toFloat(),180f,Color.rgb(76,29,149),purple,Shader.TileMode.CLAMP)
        p.shader=g;c.drawRect(0f,0f,width.toFloat(),180f,p);p.shader=null
        box(c,18f,20f,66f,68f,Color.WHITE,14f);txt(c,"FP",30f,52f,17f,purple,true)
        txt(c,"Family Persatuan",80f,44f,17f,Color.WHITE,true);txt(c,"Pejuang Creator",80f,65f,15f,gold,true)
        txt(c,"TOTAL BONUS",18f,106f,10f,0xCCFFFFFF.toInt());txt(c,"Rp 2.450.000",18f,137f,26f,Color.WHITE,true)
    }

    private fun home(c:Canvas){
        txt(c,"Halo, Creator!",18f,215f,20f,dark,true);txt(c,"Semangat berkarya dan berbagi.",18f,238f,12f,muted)
        val lab=arrayOf("Bonus Bulan Ini","Diamond","Kartu","Ranking");val valx=arrayOf("Rp 850.000","12.750","18 / 30","#28")
        for(i in 0..3){val x=18+(i%2)*192;val y=260+(i/2)*88;box(c,x.toFloat(),y.toFloat(),(x+180).toFloat(),(y+76).toFloat(),Color.WHITE,16f);txt(c,lab[i],x+13f,y+24f,10f,muted);txt(c,valx[i],x+13f,y+54f,18f,dark,true)}
        if(pendingInvitationCount>0){ box(c,18f,430f,412f,475f,gold,12f); txt(c,"🔔  $pendingInvitationCount undangan Family",32f,458f,12f,dark,true) }
        txt(c,"Aktivitas Terbaru",18f,490f,17f,dark,true);box(c,18f,505f,412f,655f,Color.WHITE,17f)
        txt(c,"🎁  Bonus Harian",32f,543f,13f,dark,true);txt(c,"+ Rp 10.000",300f,543f,12f,Color.rgb(20,150,80),true)
        txt(c,"🃏  Mendapat Kartu Baru",32f,585f,13f,dark,true);txt(c,"Kartu #20",305f,585f,12f,purple,true)
        txt(c,"🏆  Ranking naik",32f,627f,13f,dark,true);txt(c,"#29 → #28",300f,627f,12f,purple,true)
    }

    private fun cards(c:Canvas){
        txt(c,"Kartu Creator",18f,215f,20f,dark,true);box(c,18f,230f,412f,410f,Color.WHITE,19f);txt(c,"KARTU HARIAN",32f,260f,10f,purple,true)
        txt(c,"🏆",170f,322f,56f);txt(c,"Creator Inspiratif",132f,350f,16f,dark,true);txt(c,"★★★★★",168f,374f,13f,gold,true)
        box(c,32f,382f,398f,425f,purple,12f);txt(c,"KLAIM KARTU",165f,409f,12f,Color.WHITE,true)
        txt(c,"Koleksi 18 / 30",18f,462f,17f,dark,true);val icons=arrayOf("🌹","⭐","💎","🔥","👑","🎯")
        for(i in 0..5){val x=18+(i%3)*132;val y=478+(i/3)*82;box(c,x.toFloat(),y.toFloat(),(x+120).toFloat(),(y+72).toFloat(),Color.WHITE,13f);txt(c,icons[i],x+46f,y+34f,24f);txt(c,"Kartu #${i+1}",x+37f,y+57f,9f,muted)}
    }

    private fun bonus(c:Canvas){
        txt(c,"Bonus & Penarikan",18f,215f,20f,dark,true);box(c,18f,230f,412f,315f,purple,18f);txt(c,"TOTAL BONUS",32f,258f,10f,0xCCFFFFFF.toInt());txt(c,"Rp 2.450.000",32f,293f,25f,Color.WHITE,true)
        txt(c,"Riwayat Bonus",18f,355f,17f,dark,true);box(c,18f,370f,412f,520f,Color.WHITE,17f)
        val a=arrayOf("Bonus Harian","+ Rp 10.000","Bonus Ranking","+ Rp 25.000","Bonus Kartu","+ Rp 15.000")
        for(i in 0..2){txt(c,a[i*2],32f,410f+i*38,13f,dark,true);txt(c,a[i*2+1],300f,410f+i*38,12f,Color.rgb(20,150,80),true)}
        box(c,18f,545f,412f,600f,purple,14f);txt(c,"AJUKAN PENARIKAN",145f,579f,12f,Color.WHITE,true)
    }

    private fun rank(c:Canvas){
        txt(c,"Ranking Creator",18f,215f,20f,dark,true);box(c,18f,230f,412f,600f,Color.WHITE,18f)
        val names=arrayOf("Andi Creator","Salsa Live","Raka Kreator","Creator Hebat","Creator Family");val d=arrayOf("38.420","31.880","27.450","18.500","12.750")
        for(i in names.indices){val y=275+i*62;txt(c,"${i+1}",32f,y,14f,purple,true);txt(c,names[i],68f,y,13f,dark,true);txt(c,d[i]+" diamond",270f,y,11f,muted)}
    }

    private fun profile(c:Canvas){
        txt(c,"Profil Saya",18f,215f,20f,dark,true);box(c,18f,230f,412f,485f,Color.WHITE,18f);box(c,166f,250f,264f,348f,0xFFEDE9FE.toInt(),49f);txt(c,"PK",193f,312f,27f,purple,true)
        txt(c,"Creator Family",150f,378f,18f,dark,true);txt(c,"Member Aktif",177f,400f,11f,Color.rgb(20,150,80),true);txt(c,"ID Creator",32f,438f,10f,muted);txt(c,"FPC-2026-0028",32f,458f,13f,dark,true)
        val items=arrayOf("Data Rekening","Ubah PIN / Password","Keamanan Akun","Tentang Aplikasi")
        for(i in items.indices){val y=505+i*48;box(c,18f,y,412f,y+40f,Color.WHITE,12f);txt(c,items[i],34f,y+26f,13f,dark,true)}
    }

    private fun nav(c:Canvas){
        p.color=Color.WHITE;c.drawRect(0f,height-74f,width.toFloat(),height.toFloat(),p);val n=arrayOf("⌂","🎁","💰","🏆","👤");val l=arrayOf("Beranda","Kartu","Bonus","Ranking","Profil")
        for(i in n.indices){val x=i*width/5f;val col=if(tab==i)purple else muted;txt(c,n[i],x+width/10f-8f,height-43f,18f,col,true);txt(c,l[i],x+width/10f-25f,height-17f,9f,col,tab==i)}
    }

    private fun admin(c:Canvas){
        val g=LinearGradient(0f,0f,width.toFloat(),160f,Color.rgb(50,18,95),purple,Shader.TileMode.CLAMP);p.shader=g;c.drawRect(0f,0f,width.toFloat(),160f,p);p.shader=null
        txt(c,"PANEL ADMIN",22f,48f,11f,gold,true);txt(c,"Family Persatuan Pejuang Creator",22f,78f,18f,Color.WHITE,true);txt(c,"Dashboard Pengelolaan",22f,101f,12f,0xDDFFFFFF.toInt())
        if(adminTab==1){adminMembers(c);return}
        val labs=arrayOf("Total Member","Bonus Keluar","Penarikan Pending","Kartu Aktif");val vals=arrayOf("12.850","Rp 156,7 Jt","24","30")
        for(i in 0..3){val x=18+(i%2)*192;val y=180+(i/2)*90;box(c,x.toFloat(),y.toFloat(),(x+180).toFloat(),(y+76).toFloat(),Color.WHITE,15f);txt(c,labs[i],x+12f,y+24f,9f,muted);txt(c,vals[i],x+12f,y+53f,18f,dark,true)}
        txt(c,"Menu Admin",18f,390f,17f,dark,true);val m=arrayOf("👥 Member","🎁 Kartu","💰 Bonus","🏆 Ranking","💸 Penarikan","📊 Laporan")
        for(i in m.indices){val x=18+(i%2)*192;val y=405+(i/2)*58;box(c,x.toFloat(),y.toFloat(),(x+180).toFloat(),(y+49).toFloat(),Color.WHITE,12f);txt(c,m[i],x+14f,y+30f,11f,dark,true)}
        box(c,18f,600f,412f,655f,purple,14f);txt(c,"KELUAR ADMIN",160f,634f,12f,Color.WHITE,true)
    }

    private fun adminMembers(c:Canvas){
        txt(c,"←  Undang Member",20f,198f,19f,dark,true)
        txt(c,"Cari akun berdasarkan email / nomor HP",20f,225f,11f,muted)
        box(c,20f,245f,412f,300f,Color.WHITE,14f)
        txt(c,"🔎  Tekan untuk mencari member",36f,279f,13f,muted)
        checkedMember?.let { m ->
            box(c,20f,325f,412f,515f,Color.WHITE,16f)
            txt(c,"AKUN DITEMUKAN",36f,355f,10f,Color.rgb(20,150,80),true)
            txt(c,"Nama: ${m.name}",36f,385f,14f,dark,true)
            txt(c,"ID: ${m.id}",36f,414f,12f,muted)
            txt(c,"Family: ${m.familyName.ifBlank { "Belum ada" }}",36f,442f,12f,muted)
            txt(c,"Agency: ${m.agencyName.ifBlank { "Belum ada" }}",36f,470f,12f,muted)
            if(m.familyId.isBlank()) { box(c,20f,535f,412f,585f,purple,14f);txt(c,"KIRIM UNDANGAN",145f,567f,12f,Color.WHITE,true) }
            else txt(c,"Member sudah memiliki Family",36f,548f,12f,Color.rgb(190,60,60),true)
        }
    }

    private fun showLogin(){
        val username=EditText(ctx);username.hint="Username";username.setSingleLine(true)
        val pass=EditText(ctx);pass.hint="Password";pass.inputType=0x81
        val lay=LinearLayout(ctx);lay.orientation=LinearLayout.VERTICAL;lay.setPadding(40,10,40,0);lay.addView(username);lay.addView(pass)
        AlertDialog.Builder(ctx).setTitle("Masuk dengan Username").setView(lay).setPositiveButton("MASUK"){_,_->
            if(!firebaseReady()){toast("Firebase belum dikonfigurasi. Isi strings.xml terlebih dahulu.");return@setPositiveButton}
            val key=username.text.toString().trim().lowercase(Locale.US)
            if(key.isBlank() || pass.text.toString().length < 6){toast("Username wajib diisi dan password minimal 6 karakter");return@setPositiveButton}
            FirebaseFirestore.getInstance().collection("members").whereEqualTo("username",key).limit(1).get().addOnSuccessListener { snap ->
                val email=if(!snap.isEmpty) snap.documents[0].getString("email") else key
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email ?: key,pass.text.toString()).addOnSuccessListener{
                    loadCurrentMemberRole()
                }.addOnFailureListener{toast("Login gagal: ${it.message ?: "periksa username/password"}")}
            }.addOnFailureListener{toast("Gagal mencari username: ${it.message ?: "coba lagi"}")}
        }.setNegativeButton("BATAL",null).show()
    }

    private fun loadCurrentMemberRole(){
        val uid=FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseFirestore.getInstance().collection("members").document(uid).get().addOnSuccessListener{d->
            currentRole=d.getString("role") ?: "member"
            mode="app"
            loadPendingInvitations()
            invalidate()
            toast("Login berhasil")
        }.addOnFailureListener{ mode="app"; invalidate(); toast("Login berhasil, profil belum dapat dibaca") }
    }

    private fun loadPendingInvitations(){
        val uid=FirebaseAuth.getInstance().currentUser?.uid ?: return
        if(!firebaseReady()) return
        FirebaseFirestore.getInstance().collection("invitations")
            .whereEqualTo("memberId",uid).whereEqualTo("status","pending").get()
            .addOnSuccessListener{pendingInvitationCount=it.size();invalidate()}
    }

    private fun showInvitations(){
        val uid=FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseFirestore.getInstance().collection("invitations")
            .whereEqualTo("memberId",uid).whereEqualTo("status","pending").limit(10).get()
            .addOnSuccessListener{snap->
                if(snap.isEmpty){toast("Belum ada undangan Family");return@addOnSuccessListener}
                val d=snap.documents[0]
                val family=d.getString("familyName") ?: "Family"
                AlertDialog.Builder(ctx).setTitle("Undangan Family")
                    .setMessage("Kamu mendapat undangan bergabung ke $family.")
                    .setPositiveButton("TERIMA"){_,_->respondInvitation(d.id,true)}
                    .setNegativeButton("TOLAK"){_,_->respondInvitation(d.id,false)}
                    .setNeutralButton("BATAL",null).show()
            }.addOnFailureListener{toast("Gagal memuat undangan: ${it.message}")}
    }

    private fun respondInvitation(invitationId:String,accept:Boolean){
        val uid=FirebaseAuth.getInstance().currentUser?.uid ?: return
        val db=FirebaseFirestore.getInstance()
        db.collection("invitations").document(invitationId).get().addOnSuccessListener{inv->
            if(inv.getString("memberId")!=uid || inv.getString("status")!="pending"){toast("Undangan sudah tidak aktif");loadPendingInvitations();return@addOnSuccessListener}
            if(!accept){
                db.collection("invitations").document(invitationId).update("status","rejected").addOnSuccessListener{toast("Undangan ditolak");loadPendingInvitations()}
                return@addOnSuccessListener
            }
            val familyId=inv.getString("familyId") ?: ""; val familyName=inv.getString("familyName") ?: ""
            db.collection("invitations").document(invitationId).update("status","accepted").addOnSuccessListener{
                db.collection("members").document(uid).update(mapOf("familyId" to familyId,"familyName" to familyName,"acceptedInvitationId" to invitationId)).addOnSuccessListener{toast("Selamat! Kamu bergabung ke $familyName");loadPendingInvitations()}
                    .addOnFailureListener{toast("Undangan diterima, tetapi profil belum diperbarui: ${it.message}")}
            }.addOnFailureListener{toast("Gagal menerima undangan: ${it.message}")}
        }.addOnFailureListener{toast("Gagal memproses undangan: ${it.message}")}
    }

    private fun showRegister(){
        val name=EditText(ctx);name.hint="Nama lengkap"
        val username=EditText(ctx);username.hint="Username (contoh: wahyudipratama316)";username.setSingleLine(true)
        val pass=EditText(ctx);pass.hint="Password minimal 6 karakter";pass.inputType=0x81
        val lay=LinearLayout(ctx);lay.orientation=LinearLayout.VERTICAL;lay.setPadding(40,10,40,0);lay.addView(name);lay.addView(username);lay.addView(pass)
        AlertDialog.Builder(ctx).setTitle("Daftar Akun").setView(lay).setPositiveButton("DAFTAR"){_,_->
            if(!firebaseReady()){toast("Firebase belum dikonfigurasi. Isi strings.xml terlebih dahulu.");return@setPositiveButton}
            val u=username.text.toString().trim().lowercase(Locale.US).replace("\\s+".toRegex(),"")
            val password=pass.text.toString()
            if(name.text.toString().trim().isBlank() || u.isBlank() || password.length < 6){toast("Nama, username wajib diisi dan password minimal 6 karakter");return@setPositiveButton}
            val internalEmail="$u@familypersatuanpejuangcreator.app"
            FirebaseFirestore.getInstance().collection("members").whereEqualTo("username",u).limit(1).get().addOnSuccessListener { existing ->
                if(!existing.isEmpty){toast("Username sudah digunakan");return@addOnSuccessListener}
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(internalEmail,password).addOnSuccessListener{auth->
                    val uid=auth.user?.uid ?: return@addOnSuccessListener
                    val data=hashMapOf("id" to uid,"name" to name.text.toString().trim(),"username" to u,"email" to internalEmail,"phone" to "","familyId" to "","familyName" to "","agencyId" to "","agencyName" to "","role" to "member","createdAt" to System.currentTimeMillis())
                    FirebaseFirestore.getInstance().collection("members").document(uid).set(data).addOnSuccessListener{
                        currentRole="member"; mode="app"; loadPendingInvitations(); invalidate(); toast("Akun berhasil dibuat")
                    }.addOnFailureListener{toast("Akun dibuat, tetapi profil gagal disimpan")}
                }.addOnFailureListener{toast("Pendaftaran gagal: ${it.message ?: "periksa data"}")}
            }.addOnFailureListener{toast("Gagal mengecek username: ${it.message ?: "coba lagi"}")}
        }.setNegativeButton("BATAL",null).show()
    }

    private fun showMemberSearch(){
        val input=EditText(ctx);input.hint="Email atau nomor HP";input.setSingleLine(true)
        AlertDialog.Builder(ctx).setTitle("Cek Akun Member").setView(input).setPositiveButton("CEK"){_,_->searchMember(input.text.toString())}.setNegativeButton("BATAL",null).show()
    }

    private fun searchMember(raw:String){
        val key=raw.trim();if(key.isBlank()){toast("Masukkan email atau nomor HP");return}
        if(!firebaseReady()){toast("Firebase belum dikonfigurasi.");return}
        val db=FirebaseFirestore.getInstance();val q=key.lowercase(Locale.US)
        db.collection("members").whereEqualTo("email",q).limit(1).get().addOnSuccessListener{snap->
            if(!snap.isEmpty){useMember(snap.documents[0]);return@addOnSuccessListener}
            db.collection("members").whereEqualTo("phone",key).limit(1).get().addOnSuccessListener{snap2->
                if(!snap2.isEmpty) useMember(snap2.documents[0]) else {checkedMember=null;invalidate();toast("Akun member tidak ditemukan")}
            }.addOnFailureListener{toast("Gagal mengecek nomor HP: ${it.message}")}
        }.addOnFailureListener{toast("Gagal mengecek email: ${it.message}")}
    }

    private fun useMember(d:com.google.firebase.firestore.DocumentSnapshot){
        checkedMember=Member(d.id,d.getString("name")?:(d.getString("email")?:"-"),d.getString("email")?:("-"),d.getString("phone")?:"",d.getString("familyId")?:"",d.getString("familyName")?:"",d.getString("agencyId")?:"",d.getString("agencyName")?:"")
        invalidate();toast("Akun ditemukan")
    }

    private fun sendInvitation(){
        val m=checkedMember?:return
        if(m.familyId.isNotBlank()){toast("Member sudah berada di Family lain");return}
        if(!firebaseReady()){toast("Firebase belum dikonfigurasi.");return}
        val db=FirebaseFirestore.getInstance();val familyId="FPC_MAIN";val familyName="Family Persatuan Pejuang Creator";val adminUid=FirebaseAuth.getInstance().currentUser?.uid?:"admin-demo"
        db.collection("invitations").whereEqualTo("memberId",m.id).whereEqualTo("familyId",familyId).whereEqualTo("status","pending").limit(1).get().addOnSuccessListener{existing->
            if(!existing.isEmpty){toast("Undangan masih menunggu penerimaan");return@addOnSuccessListener}
            val data=hashMapOf("memberId" to m.id,"memberName" to m.name,"memberEmail" to m.email,"memberPhone" to m.phone,"familyId" to familyId,"familyName" to familyName,"agencyId" to m.agencyId,"agencyName" to m.agencyName,"status" to "pending","invitedBy" to adminUid,"createdAt" to System.currentTimeMillis())
            db.collection("invitations").add(data).addOnSuccessListener{toast("Undangan berhasil dikirim");invalidate()}.addOnFailureListener{toast("Gagal mengirim undangan: ${it.message}")}
        }.addOnFailureListener{toast("Gagal mengecek undangan: ${it.message}")}
    }

    private fun toast(s:String)=Toast.makeText(ctx,s,Toast.LENGTH_LONG).show()

    override fun onTouchEvent(e:android.view.MotionEvent):Boolean{
        if(e.action!=android.view.MotionEvent.ACTION_UP)return true
        val x=e.x;val y=e.y
        when(mode){
            "login"->{if(y>470&&y<550)showLogin() else if(y>540)showRegister() else if(x>340&&y<80){
                if(currentRole=="admin"){mode="admin";invalidate()} else toast("Akses admin ditolak")
            }}
            "register"->{if(y<75){mode="login";invalidate()}else if(y>440&&y<540)showRegister()}
            "admin"->{
                if(adminTab==1){if(y>240&&y<315)showMemberSearch() else if(y>525&&y<600&&checkedMember!=null)sendInvitation() else if(y<215){adminTab=0;checkedMember=null;invalidate()}}
                else {if(y in 405f..465f && x<210){adminTab=1;invalidate()} else if(y>585){mode="login";invalidate()}}
            }
            else->{if(y>height-95){tab=(x/(width/5f)).toInt().coerceIn(0,4);invalidate()} else if(tab==0&&pendingInvitationCount>0&&y in 420f..485f)showInvitations() else if(tab==1&&y>370&&y<450)toast("Kartu harian berhasil diklaim.") else if(tab==2&&y>520)toast("Pengajuan penarikan dicatat.") else if(tab==4&&y>680){FirebaseAuth.getInstance().signOut();currentRole="member";pendingInvitationCount=0;mode="login";invalidate()}}
        }
        return true
    }

    data class Member(val id:String,val name:String,val email:String,val phone:String,val familyId:String,val familyName:String,val agencyId:String,val agencyName:String)
}
